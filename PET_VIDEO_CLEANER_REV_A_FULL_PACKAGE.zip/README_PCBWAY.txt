PET VIDEO CLEANER — REV A — PCBWAY GERBER PACKAGE

Generated from: PET_VIDEO_CLEANER_REV_A_CAP_LABEL_2_KiCad.zip

Board:
- Size: 55.0 mm x 25.5 mm
- 2 layers
- Through-hole plated drills
- Front silkscreen only
- Front and back solder mask

Recommended PCBWay options:
- 2 layers
- FR-4
- 1.6 mm thickness
- 1 oz copper
- HASL or ENIG finish

Files:
- PET_VIDEO_CLEANER_REV_A-F_Cu.gtl
- PET_VIDEO_CLEANER_REV_A-B_Cu.gbl
- PET_VIDEO_CLEANER_REV_A-F_Mask.gts
- PET_VIDEO_CLEANER_REV_A-B_Mask.gbs
- PET_VIDEO_CLEANER_REV_A-F_Silkscreen.gto
- PET_VIDEO_CLEANER_REV_A-Edge_Cuts.gm1
- PET_VIDEO_CLEANER_REV_A-PTH.drl

Before ordering:
Upload PET_VIDEO_CLEANER_REV_A_PCBWay_Gerbers.zip to PCBWay and inspect their Gerber viewer.
Confirm:
- board outline is 55.0 x 25.5 mm
- UG11 plug is at the far left
- pin-1 orientation is notch down / pin 1 bottom-right on all three DIP-14 footprints
- all holes are visible
- C1 104 label is visible near the two capacitor pads
