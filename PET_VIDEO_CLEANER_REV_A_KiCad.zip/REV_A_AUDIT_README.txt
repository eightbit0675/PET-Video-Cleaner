PET VIDEO CLEANER — REV A — NEW SCRATCH DESIGN

This project was generated from a clean board layout, not by editing the failed Rev G/H routing.

Confirmed physical DIP orientation used on all three 14-pin footprints:
- Notch DOWN when viewed from the top of the board.
- Pin 1 is bottom-right.
- Right row bottom-to-top: 1,2,3,4,5,6,7.
- Left row top-to-bottom: 8,9,10,11,12,13,14.
- Pin 14 is bottom-left.

Board/mechanical:
- Board size: 55.0 mm x 25.5 mm.
- P1 / UG11 motherboard plug is at the far left.
- Leftmost pad copper on P1 has about 1.20 mm clearance to the board edge.
- Board extends to the right.
- C1 104 / 0.1 uF is placed near U2 74LS74.
- Socket-hidden labels: UG11, 74LS20, 74LS74.
- Visible labels: PET VIDEO CLEANER, Bruce Philip • 2026 • REV A, CLK8 → UE11 PIN 2.

Electrical intent:
- P1 pins 1-5 and 7-14 pass through to same-number U1 pins.
- P1 pin 6 is NOT connected directly to U1 pin 6.
- U1 pin 6 / VIDEO_RAW connects to U2 pin 2 / D1.
- U2 pin 5 / Q1 connects to P1 pin 6 / VIDEO_CLEAN.
- J1 CLK8 connects to U2 pin 3.
- U2 pins 1,4,10,13,14 are tied to +5V.
- U2 pins 7,11,12 are tied to GND.
- U2 pins 6,8,9 are no-connect.

Independent pre-check performed here:
- Different-net track-to-pad clearance violations found: 0
- Different-net track-to-track clearance violations found: 0
- Connectivity missing in internal graph: 0

KiCad still has to be the final authority. Open the board, run DRC with unconnected items enabled, and send the report before this is used for PCBWay.


REV A FINAL CHANGE:
- Moved only the front silkscreen text "CLK8 → UE11 PIN 2" from X=50.3 mm to X=45.8 mm.
- This addresses the KiCad DRC warning: silk_edge_clearance at the right board edge.
- Copper, routing, pads, drills, netlist, footprint placement, and board outline were not changed.


REV A FINAL 2 CHANGE:
- Removed the duplicate board-level silkscreen text "CLK8 → UE11 PIN 2".
- Kept the J1 footprint silkscreen labels "CLK8" and "UE11 PIN 2".
- No copper, routing, pads, holes, nets, board outline, or footprint placement changed.
